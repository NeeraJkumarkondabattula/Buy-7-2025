document.addEventListener("DOMContentLoaded", function () {
  const facewashProductId = "7517413441716"; // Replace with the facewash product ID
  const sunscreenProductId = "7798479388852"; // Replace with the sunscreen product ID

  function addProductToCart(productId) {
    fetch("/cart/add.js", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ id: productId, quantity: 1 }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Product added:", data);
        location.reload(); // Optional: reload to update cart display
      })
      .catch((error) => console.error("Error adding product:", error));
  }

  function checkCartForFacewash() {
    fetch("/cart.js")
      .then((response) => response.json())
      .then((cart) => {
        const hasFacewash = cart.items.some(
          (item) => item.variant_id == facewashProductId
        );
        const hasSunscreen = cart.items.some(
          (item) => item.variant_id == sunscreenProductId
        );

        if (hasFacewash && !hasSunscreen) {
          addProductToCart(sunscreenProductId);
        }
      })
      .catch((error) => console.error("Error checking cart:", error));
  }

  // Run this function whenever a cart update event is triggered
  document.addEventListener("cart:updated", checkCartForFacewash);
});
